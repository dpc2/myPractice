#include "my_computations.hpp"

void print_triple_number(int number)
{
    cout << triple_number(number) << endl;
}

int triple_number(int number)
{
    return number * 3;
}
