#ifndef MY_COMPUTATIONS_H 
#define MY_COMPUTATIONS_H

#include <iostream>

using namespace std;

int triple_number(int number);
void print_triple_number(int number);


#endif
