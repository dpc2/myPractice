#include <iostream>
#include "my_computations.hpp"

using namespace std;

int main()
{
    print_triple_number(4);
    return 0;
}
